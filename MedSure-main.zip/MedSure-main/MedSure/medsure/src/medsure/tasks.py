from crewai import Task
from.agents import report_analyst, medical_data_interpreter, patient_summary_agent

extract_text_from_report = Task(
    description=(
        'Using the LabReportOCRTool, process the image located at {file_path} and extract all '
        'textual content. The output must be the complete, raw text from the report.'
    ),
    expected_output='A single string containing all the text extracted from the medical report image.',
    agent=report_analyst
)

interpret_medical_data = Task(
    description=(
        "Analyze the raw text provided in the context from the previous task. For each medical "
        "parameter you can identify (e.g., 'Hemoglobin', 'Platelets', 'ALT'), extract its "
        "measured value and its units. Then, use the MedicalKnowledgeBaseTool to find the normal "
        "reference range for that parameter. Finally, compile all findings into a structured "
        "JSON format. Assume the patient is a 'male' for population-specific lookups."
    ),
    expected_output=(
        'A JSON string containing a list of objects. Each object must represent a medical '
        'parameter with the following keys: "parameter_name", "value", "unit", '
        '"status" (which can be "Normal", "Low", or "High"), and "normal_range" (a string '
        "representing the low and high values, e.g., '13.5 - 17.5 g/dL')."
    ),
    agent=medical_data_interpreter,
    context=[extract_text_from_report] # This task depends on the output of the first task
)

generate_patient_summary = Task(
    description=(
        "Take the structured JSON data from the previous task's context. Generate a patient-friendly "
        "summary in Markdown format. The summary must have two main sections: '## Key Findings' "
        "and '## Next Steps'.\n\n"
        "Under 'Key Findings', list each parameter that was found to be 'Low' or 'High'. For each of "
        "these abnormal results, provide a simple, one-sentence explanation of what that parameter "
        "generally relates to. For example, for Hemoglobin, you might say: 'This relates to your "
        "blood's ability to carry oxygen.'\n\n"
        "Under 'Next Steps', provide a concluding paragraph advising consultation.\n\n"
        "Crucially, you MUST end the entire report with the following disclaimer, exactly as written:\n"
        "\"**Disclaimer:** This is an AI-generated summary and is for informational purposes only. "
        "It is not a medical diagnosis. Please consult with a qualified healthcare professional to "
        "discuss your results and for any medical advice.\""
    ),
    expected_output=(
        "A well-formatted Markdown report with the specified 'Key Findings' and 'Next Steps' sections,"
        "clear and simple explanations for any abnormal results, and the mandatory disclaimer at the end."
    ),
    agent=patient_summary_agent,
    context=[interpret_medical_data] # This task depends on the output of the second task
)