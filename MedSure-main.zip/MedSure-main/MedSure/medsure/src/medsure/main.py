import os
from dotenv import load_dotenv

load_dotenv()

from medsure.crew import medical_crew

from PIL import Image
import pytesseract

ocr_text = pytesseract.image_to_string(Image.open("sample_report.png"))
print("\n[DEBUG] OCR Output:\n", ocr_text)


def run():
    """
    Runs the medical report analysis crew with a sample report.
    """
    inputs = {
        'file_path': 'sample_report.png'
    }

    # Limit agent looping
    result = medical_crew.kickoff(inputs=inputs)

    print("\n\n########################")
    print("## Final Report")
    print("########################\n")
    print(result)


if __name__ == "__main__":
    run()
