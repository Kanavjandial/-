import os
import re
from PIL import Image
import pytesseract
from dotenv import load_dotenv
from crewai.tools import BaseTool

load_dotenv()

# Add a basic reference range dictionary
REFERENCE_RANGES = {
    "Hemoglobin": {"unit": "g/dL", "min": 13.0, "max": 17.0},
    "WBC Count": {"unit": "/uL", "min": 4000, "max": 11000},
    "Platelet Count": {"unit": "/uL", "min": 150000, "max": 450000},
    "Blood Glucose (Fasting)": {"unit": "mg/dL", "min": 70, "max": 99},
    "Cholesterol Total": {"unit": "mg/dL", "min": 0, "max": 200},
}

class LabReportOCRTool(BaseTool):
    name: str = "Local Lab Report OCR Tool"
    description: str = "Extracts text from lab report using Tesseract OCR and interprets parameters locally using regex."

    def _run(self, file_path: str) -> str:
        try:
            if not os.path.exists(file_path):
                return f"❌ Error: File not found at '{file_path}'"

            # OCR using Tesseract
            image = Image.open(file_path)
            raw_text = pytesseract.image_to_string(image)

            if not raw_text.strip():
                return "❌ OCR failed: No text could be extracted."

            # Clean & extract parameters
            parameters = self.extract_parameters(raw_text)
            if not parameters:
                return "❌ No valid lab parameters found in the report."

            # Interpret values
            results = []
            for param in parameters:
                name, value, unit = param["name"], param["value"], param["unit"]
                status, range_text = self.interpret(name, value)
                results.append(f"{name}: {value} {unit} ➜ {status} (Normal range: {range_text})")

            return "\n".join(results)

        except Exception as e:
            return f"❌ An error occurred: {str(e)}"

    def extract_parameters(self, text: str):
        # Regex to match lines like "Hemoglobin: 13.5 g/dL"
        pattern = re.compile(r"([A-Za-z ()]+):?\s*([\d.]+)\s*(\S+)", re.IGNORECASE)
        results = []
        for match in pattern.finditer(text):
            results.append({
                "name": match.group(1).strip(),
                "value": float(match.group(2).strip()),
                "unit": match.group(3).strip()
            })
        return results

    def interpret(self, name: str, value: float):
        # Find closest match for the name
        for key, ref in REFERENCE_RANGES.items():
            if key.lower() in name.lower():
                min_val, max_val = ref["min"], ref["max"]
                if value < min_val:
                    status = "Low"
                elif value > max_val:
                    status = "High"
                else:
                    status = "Normal"
                return status, f"{min_val} - {max_val} {ref['unit']}"
        return "Unknown Parameter", "N/A"
