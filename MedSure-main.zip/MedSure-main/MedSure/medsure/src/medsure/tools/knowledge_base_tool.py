from pydantic import BaseModel, Field  # ✅ Don't use .v1
from typing import Type, Optional
from crewai.tools import BaseTool
import json


class MedicalKnowledgeInput(BaseModel):
    """Input schema for the MedicalKnowledgeBaseTool."""
    parameter_name: str = Field(..., description="The name of the medical parameter to look up.")
    population: Optional[str] = Field(default="general", description="The patient population (e.g., 'male', 'female', 'child'). Defaults to 'general'.")


class MedicalKnowledgeBaseTool(BaseTool):
    name: str = "Medical Knowledge Base"
    description: str = "Provides normal reference ranges for various medical lab parameters. You can specify a parameter name and an optional population group."
    args_schema: Type[BaseModel] = MedicalKnowledgeInput  # ✅ Make sure this is typed correctly
    _knowledge_base: dict = None

    def _load_knowledge_base(self):
        if self._knowledge_base is None:
            with open('knowledge/medical_references.json', 'r') as f:
                self._knowledge_base = json.load(f)

    def _run(self, parameter_name: str, population: str = "general") -> str:
        self._load_knowledge_base()
        query_name = parameter_name.lower()

        for category in self._knowledge_base.values():
            for parameter_data in category:
                param_names = [parameter_data['parameter'].lower()] + [alias.lower() for alias in parameter_data.get('aliases', [])]
                if query_name in param_names:
                    # Find the correct range for the specified population
                    target_range = next((r for r in parameter_data['ranges'] if r['population'].lower() == population.lower()), None)
                    # Fallback to 'general' if specific population not found
                    if not target_range:
                        target_range = next((r for r in parameter_data['ranges'] if r['population'].lower() == 'general'), None)

                    if target_range:
                        return json.dumps(target_range)
                    else:
                        return f"Error: No range found for population '{population}' for parameter '{parameter_name}'."

        return f"Error: Parameter '{parameter_name}' not found in the knowledge base."
