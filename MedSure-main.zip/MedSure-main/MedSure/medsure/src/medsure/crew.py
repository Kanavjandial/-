from crewai import Crew, Process
from.agents import report_analyst, medical_data_interpreter, patient_summary_agent
from.tasks import extract_text_from_report, interpret_medical_data, generate_patient_summary

# Assemble the crew with a sequential process
medical_crew = Crew(
    agents=[report_analyst, medical_data_interpreter, patient_summary_agent],
    tasks=[extract_text_from_report, interpret_medical_data, generate_patient_summary],
    process=Process.sequential,
    verbose=True # Set to 2 for detailed agent thought processes
)