import os
from telegram import Update, Bot
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from medsure.crew import medical_crew
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_TOKEN")
bot = Bot(token=TOKEN)

# Start command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📄 Send me your lab report image and I’ll analyze it.")

async def handle_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo = update.message.photo[-1]
    file = await photo.get_file()
    image_path = "sample_report.png"
    await file.download_to_drive(image_path)

    # Run the crew pipeline
    result = medical_crew.kickoff(inputs={"file_path": image_path})

    try:
        final_output = result.tasks_output[-1].result
    except Exception as e:
        final_output = f"⚠️ Something went wrong while processing the report:\n{e}"

    await update.message.reply_text(
        "✅ Report Processed:\n\n" + str(final_output),
        parse_mode="Markdown"
    )

# Setup and run
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.PHOTO, handle_image))

if __name__ == "__main__":
    app.run_polling()
